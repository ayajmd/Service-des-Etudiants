<?php
require_once '../config/dbconfig.php';

// Récupérez les données envoyées depuis la requête AJAX
$data = json_decode(file_get_contents('php://input'), true);
$email = $data['email'];

// Connexion à la base de données
$db = Database::connect();

// Requête pour vérifier si l'email existe dans la base de données
$emailQuery = "SELECT * FROM etudiants WHERE Email = :email";
$emailStmt = $db->prepare($emailQuery);
$emailStmt->bindParam(':email', $email);
$emailStmt->execute();    

// Format de la réponse à envoyer au JavaScript
$response = array();

if ($emailStmt->rowCount() > 0) {
    // L'email existe dans la base de données
    $response['exists'] = true;
} else {
    // L'email n'existe pas dans la base de données
    $response['exists'] = false;
}

// Renvoyer la réponse JSON
header('Content-Type: application/json');
echo json_encode($response);

// Fermez la connexion à la base de données
$db = null;
?>
