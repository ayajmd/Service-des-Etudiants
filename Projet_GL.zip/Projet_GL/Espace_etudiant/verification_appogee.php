<?php
require_once '../config/dbconfig.php';

// Récupération des données envoyées depuis la requête AJAX
$data = json_decode(file_get_contents('php://input'), true);
$appogee = $data['appogee'];

// Connexion à la base de données
$db = Database::connect();

// Requête pour vérifier si l'apogée existe dans la base de données
$appogeeQuery = "SELECT * FROM etudiants WHERE apogee = :appogee";
$appogeeStmt = $db->prepare($appogeeQuery);
$appogeeStmt->bindParam(':appogee', $appogee);
$appogeeStmt->execute();

// Format de la réponse à envoyer au JavaScript
$response = array();

if ($appogeeStmt->rowCount() > 0) {
    // L'apogée existe dans la base de données
    $response['exists'] = true;
} else {
    // L'apogée n'existe pas dans la base de données
    $response['exists'] = false;
}

// Renvoi de la réponse JSON
header('Content-Type: application/json');
echo json_encode($response);

// Fermeture de la connexion à la base de données
$db = null;
?>
