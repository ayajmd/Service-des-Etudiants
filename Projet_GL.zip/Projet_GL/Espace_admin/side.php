
    <!-- =============== Navigation ================ -->
    <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon">
                        </span>
                    </a>
                </li>
                <li>
                    <a href="admin_dashboard.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Tableau de bord</span>
                    </a>
                </li>
                <li>
                    <a href="Demandes_1.php">
                        <span class="icon">
                        <ion-icon name="mail-unread-outline"></ion-icon>
                        </span>
                        <span class="title">Demandes</span>
                    </a>
                </li>
                <li>
                    <a href="space_reclamation.php">
                        <span class="icon">
                        <ion-icon name="alert-circle-outline"></ion-icon>
                        </span>
                        <span class="title">Réclamations</span>
                    </a>
                </li>
                <li>
                    <a href="history3.php">
                        <span class="icon">
                        <ion-icon name="time-outline"></ion-icon>                        </span>
                        <span class="title">Historique</span>
                    </a>
                </li>        
                <li>
                    <a href="deconnexion_admin.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Déconnexion</span>
                    </a>
                </li>
            </ul>
    </div>
     <!-- =========== Scripts =========  -->
   <script src="main.js"></script>
<!-- ====== ionicons ======= -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>