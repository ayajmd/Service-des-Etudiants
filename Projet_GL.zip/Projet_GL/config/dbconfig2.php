<?php //configuration de connexion à notre base de données
  $hostname = "localhost";
  $username = "root";
  $password = "";
  $dbname = "serveetudant_2";
  $port = "3307";

  $conn = mysqli_connect($hostname, $username, $password, $dbname, $port);
  if(!$conn){
    echo "Erreur de connexion à la base de données".mysqli_connect_error();
  }
?>